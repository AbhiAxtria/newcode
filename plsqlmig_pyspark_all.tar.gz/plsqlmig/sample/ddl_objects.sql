CREATE TABLE ar_customer (
  cust_id    NUMBER,
  name       VARCHAR2(100),
  region_id  NUMBER,
  created_dt DATE
);

ALTER TABLE ar_customer ADD (status VARCHAR2(10), updated_dt DATE);

CREATE SEQUENCE ar_customer_seq START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE UNIQUE INDEX ar_customer_pk ON ar_customer (cust_id);

CREATE INDEX ar_customer_region_ix ON ar_customer (region_id, status);

CREATE OR REPLACE SYNONYM cust_syn FOR remote_schema.ar_customer;

CREATE PUBLIC DATABASE LINK crm_link CONNECT TO etl IDENTIFIED BY pw USING 'CRMDB';

CREATE OR REPLACE VIEW active_customers_v AS
  SELECT cust_id, name, region_id
  FROM ar_customer
  WHERE status = 'ACTIVE';

CREATE OR REPLACE PROCEDURE load_customers IS
BEGIN
  INSERT INTO ar_customer (cust_id, name, region_id)
  SELECT ar_customer_seq.NEXTVAL, c.name, c.region_id
  FROM source_customers@crm_link c
  JOIN cust_syn s ON s.cust_id = c.cust_id;
  COMMIT;
END load_customers;
/
