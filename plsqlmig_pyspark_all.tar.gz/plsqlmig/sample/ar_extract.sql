---------------------------------------------------
-- MAIN CONTROLLER
---------------------------------------------------
create  PROCEDURE RUN_AR_EXTRACT (
    Action_Ind   IN PLS_INTEGER DEFAULT 0,
    DateStr      IN DATE DEFAULT NULL,
    SingleTable  IN VARCHAR2 DEFAULT NULL,
    EffDateTrue  IN PLS_INTEGER DEFAULT 1
)
IS
BEGIN
    -- Start job 
    SingleExtractOpen;

    IF SingleTable IS NULL THEN
        TruncateTable;
        Populate_Tables;
    ELSE
        Populate_SingleTable(SingleTable);
    END IF;

    SingleExtractClose('SUCCESS');

EXCEPTION
    WHEN OTHERS THEN
        gstrMsg := TO_CHAR(SQLCODE) || ':' || SUBSTR(SQLERRM, 1, 200);
        ROLLBACK;
        SingleExtractClose('FAILED');
        RAISE;
END RUN_AR_EXTRACT;

---------------------------------------------------
-- TRUNCATE TABLES
---------------------------------------------------
create PROCEDURE TruncateTable IS
BEGIN
    DELETE FROM exttrhst.AR_EXTRACT_STATUS
    WHERE extr_run_dt < SYSDATE - 90;

    EXECUTE IMMEDIATE 'truncate table AR_ACCOUNT_INFO';
    EXECUTE IMMEDIATE 'truncate table AR_BALANCE';
    EXECUTE IMMEDIATE 'truncate table AR_CODE_DESC';
    EXECUTE IMMEDIATE 'truncate table AR_CONVERSION_RT';
    EXECUTE IMMEDIATE 'truncate table AR_CUSTOMER';
    EXECUTE IMMEDIATE 'truncate table AR_FACILITY';
    EXECUTE IMMEDIATE 'truncate table AR_PRODUCT';
    EXECUTE IMMEDIATE 'truncate table AR_RISK_TYPE';
    EXECUTE IMMEDIATE 'truncate table AR_RISK_TYPE_MAP';
    EXECUTE IMMEDIATE 'truncate table AR_MONITORING_INFO';
    EXECUTE IMMEDIATE 'truncate table AR_ACCOUNT_GROUP';
END TruncateTable;

---------------------------------------------------
-- LOAD ALL TABLES
---------------------------------------------------
create PROCEDURE Populate_Tables IS
BEGIN

    -- CODE DESC
    gstrLoadingTable := 'AR_CODE_DESC';
    SingleExtractOpen;
    extr_CODE_DESC;
    SingleExtractClose;

    -- CUSTOMER
    gstrLoadingTable := 'AR_CUSTOMER';
    SingleExtractOpen;
    extr_Customer;
    SingleExtractClose;

    -- FACILITY
    gstrLoadingTable := 'AR_FACILITY';
    SingleExtractOpen;
    extr_Facility;
    SingleExtractClose;

    -- PRODUCT
    gstrLoadingTable := 'AR_PRODUCT';
    SingleExtractOpen;
    extr_Product;
    SingleExtractClose;

    -- RISK TYPE
    gstrLoadingTable := 'AR_RISK_TYPE';
    SingleExtractOpen;
    extr_RiskType;
    SingleExtractClose;

    -- BALANCE
    gstrLoadingTable := 'AR_BALANCE';
    SingleExtractOpen;
    extr_Balance;
    SingleExtractClose;

    -- ACCOUNT INFO
    gstrLoadingTable := 'AR_ACCOUNT_INFO';
    SingleExtractOpen;
    extr_Account_Info;
    SingleExtractClose;

    -- ACCOUNT GROUP
    gstrLoadingTable := 'AR_ACCOUNT_GROUP';
    SingleExtractOpen;
    extr_Account_Group;
    SingleExtractClose;

    -- MONITORING INFO
    gstrLoadingTable := 'AR_MONITORING_INFO';
    SingleExtractOpen;
    extr_Monitoring_Info;
    SingleExtractClose;

    DBMS_STATS.GATHER_SCHEMA_STATS(NULL, cascade => TRUE);

EXCEPTION
    WHEN OTHERS THEN
        gstrMsg := TO_CHAR(SQLCODE) || ':' || SUBSTR(SQLERRM, 1, 200);
        ROLLBACK;
        SingleExtractClose('FAILED');
        RAISE;
END Populate_Tables;

---------------------------------------------------
-- LOAD SINGLE TABLE
---------------------------------------------------
create PROCEDURE Populate_SingleTable (SingleTable IN VARCHAR2)
IS
BEGIN
    IF SingleTable IS NULL THEN
        RETURN;

    ELSIF SingleTable = 'IE_CUSTOMER' THEN
        EXECUTE IMMEDIATE 'truncate table IE_CUSTOMER';
        gstrLoadingTable := 'IE_CUSTOMER';
        SingleExtractOpen;
        extr_Customer;
        SingleExtractClose;

    ELSIF SingleTable = 'IE_BALANCE' THEN
        EXECUTE IMMEDIATE 'truncate table IE_BALANCE';
        gstrLoadingTable := 'IE_BALANCE';
        SingleExtractOpen;
        extr_Balance;
        SingleExtractClose;

    ELSIF SingleTable = 'IE_PRODUCT' THEN
        EXECUTE IMMEDIATE 'truncate table IE_PRODUCT';
        gstrLoadingTable := 'IE_PRODUCT';
        SingleExtractOpen;
        extr_Product;
        SingleExtractClose;

    END IF;

EXCEPTION
    WHEN OTHERS THEN
        gstrMsg := TO_CHAR(SQLCODE) || ':' || SUBSTR(SQLERRM, 1, 200);
        ROLLBACK;
        SingleExtractClose('FAILED');
        RAISE;
END Populate_SingleTable;

---------------------------------------------------
-- LOG START
---------------------------------------------------
create PROCEDURE SingleExtractOpen IS
BEGIN
    INSERT INTO exttrhst.STATUS
    (ID, PROCESS, ACTION, STATUS, start_dt, end_dt)
    VALUES
    (gExtractId, 'AR_EXTRACT', gstrLoadingTable, 'JOB_PROCESSING', SYSDATE, NULL);

    COMMIT;
END SingleExtractOpen;

---------------------------------------------------
-- LOG END
---------------------------------------------------
create PROCEDURE SingleExtractClose (p_status VARCHAR2 DEFAULT 'SUCCESS') IS
BEGIN
    UPDATE exttrhst.STATUS
    SET STATUS = p_status,
        end_dt = SYSDATE
    WHERE ID = gExtractId;

    COMMIT;
END SingleExtractClose;

