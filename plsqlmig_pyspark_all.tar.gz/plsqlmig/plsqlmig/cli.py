"""
CLI: parse a multi-file PL/SQL corpus with a real AST front end, build the
canonical knowledge graph, validate it, store it in Neo4j, and decide
convert-to-PySpark vs keep-in-Oracle per routine (logic-pattern driven).

  python -m plsqlmig.cli FILE [FILE ...] [options]

Options:
  --schema NAME        schema/owner name for the Schema root node
  --regex              use the legacy regex front end instead of the AST parser
  --graph-only         build + validate + knowledge graph, then stop (no PySpark)
  --neo4j-uri/user/pass   live Neo4j ingest
  --dry-run            emit Cypher instead of connecting
  --cypher-out PATH    write Cypher (constraints + MERGE) here
  --pyspark-out PATH   write generated PySpark here
  --pyspark-all        generate PySpark for EVERY procedure/function, not only
                        CONVERT/REWRITE verdicts (KEEP/ORCHESTRATION are marked)
  --validate-out PATH  write a post-migration validation script here (compares
                        each converted/rewritten table's Oracle output to its
                        PySpark output: schema, row count, checksum)
  --no-columns         skip Column nodes (smaller graph)
"""
from __future__ import annotations

import argparse
import json
import sys

from . import (score_graph, generate_pyspark, generate_validation, ingest,
               enrich_knowledge_graph, graph_verdict, schema)
from .ast_builder import parse_corpus, build_graph_from_corpus


def _build_regex(paths, schema_name, include_columns):
    from .plsql_structure import parse_source
    from .graph_builder import build_graph
    objs = []
    for p in paths:
        objs.extend(parse_source(open(p).read()))
    return build_graph(objs, schema_name=schema_name, include_columns=include_columns)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="plsqlmig")
    p.add_argument("sql_files", nargs="+")
    p.add_argument("--schema", default=None)
    p.add_argument("--regex", action="store_true")
    p.add_argument("--graph-only", action="store_true")
    p.add_argument("--neo4j-uri", default="bolt://localhost:7687")
    p.add_argument("--neo4j-user", default="neo4j")
    p.add_argument("--neo4j-pass", default="neo4j")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--cypher-out", default=None)
    p.add_argument("--pyspark-out", default=None)
    p.add_argument("--pyspark-all", action="store_true",
                   help="generate PySpark for every procedure/function, whatever its verdict")
    p.add_argument("--validate-out", default=None,
                   help="write a post-migration validation script (schema/row-count/"
                        "checksum diff between Oracle and PySpark output) here")
    p.add_argument("--pipeline-out", default=None, help="write hybrid execution plan (JSON)")
    p.add_argument("--driver-out", default=None, help="write runnable pipeline driver (.py)")
    p.add_argument("--rollup-out", default=None,
                   help="write per-routine subtree summary report (CSV)")
    p.add_argument("--ext", default=None,
                   help="comma-separated source file extensions to scan "
                        "(default: sql,pks,pkb,prc,fnc,trg,vw,...). Case-insensitive.")
    p.add_argument("--no-columns", action="store_true")
    p.add_argument("--repo-name", default=None, help="repository name for provenance")
    p.add_argument("--git-branch", default=None, help="git branch name for provenance")
    args = p.parse_args(argv)

    cols = not args.no_columns
    provenance = {}
    if args.repo_name:
        provenance["repo_name"] = args.repo_name
        provenance["git_repo_name"] = args.repo_name
    if args.git_branch:
        provenance["git_branch_name"] = args.git_branch

    # Expand any directory arguments into their source files; derive a root name.
    import os
    # default source extensions (case-insensitive): plain SQL + common Oracle
    # PL/SQL object files. Override/extend with --ext.
    default_exts = {"sql", "pks", "pkb", "pkg", "prc", "fnc", "fun",
                    "trg", "vw", "pls", "plb", "tps", "tpb", "spc", "bdy"}
    exts = {e.strip().lower().lstrip(".")
            for e in (args.ext.split(",") if args.ext else [])} or default_exts

    def _scan_dir(root):
        found, ndirs = [], 0
        for dirpath, _dirs, filenames in os.walk(root, followlinks=True):
            ndirs += 1
            for fn in filenames:
                ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
                if ext in exts:
                    found.append(os.path.join(dirpath, fn))
        return sorted(found), ndirs

    files, root_name, base_dir = [], None, None
    for arg in args.sql_files:
        if os.path.isdir(arg):
            found, ndirs = _scan_dir(arg)
            files.extend(found)
            root_name = os.path.basename(os.path.normpath(arg))
            base_dir = os.path.abspath(arg)            # paths relative to this folder
            print(f"Scanned {ndirs} director(y/ies) under '{arg}': "
                  f"found {len(found)} source file(s) "
                  f"[extensions: {', '.join(sorted(exts))}]")
            if not found:
                print(f"  WARNING: no matching files under '{arg}'. "
                      f"Check --ext if your files use other extensions.")
        elif os.path.isfile(arg):
            files.append(arg)
        else:
            print(f"  WARNING: input not found: {arg}")
    if root_name is None and len(files) > 1:
        root_name = os.path.basename(os.path.dirname(os.path.commonprefix(files))) or "input"
    args.sql_files = files

    print(f"Corpus: {len(args.sql_files)} file(s)  front-end: "
          f"{'regex' if args.regex else 'AST'}")

    if args.regex:
        g = _build_regex(args.sql_files, args.schema, cols)
    else:
        corpus = parse_corpus(args.sql_files)
        for path, nodes in corpus:
            print(f"  {path}: {len(nodes)} top-level object(s)")
        g = build_graph_from_corpus(corpus, schema_name=args.schema,
                                    include_columns=cols, provenance=provenance,
                                    root_name=root_name, base_dir=base_dir)

    print(f"\nCanonical graph: {json.dumps(g.stats())}")
    violations = schema.validate_graph(g)
    print(f"Schema conformance: {'OK' if not violations else violations}")

    scores = score_graph(g)
    enrich_knowledge_graph(g, scores)
    from .rollup import add_rollups
    add_rollups(g)
    print(f"Knowledge graph:  {json.dumps(g.stats())}")

    print("\nMigration verdict (logic-pattern driven, read back from the graph)")
    print("-" * 76)
    order = {"CONVERT_TO_PYSPARK": 0, "REWRITE_FOR_PYSPARK": 1,
             "ORCHESTRATION": 2, "KEEP_IN_ORACLE": 3}
    for v in sorted(graph_verdict(g), key=lambda x: order.get(x["decision"], 9)):
        owner = f"{v['owner']}." if v["owner"] else ""
        print(f"  {owner}{v['routine']}")
        print(f"     logic={v['logic_pattern']}  ->  {v['decision']}  "
              f"(confidence {v['confidence']})")
        if v["blocking"]:
            print(f"     blocked by: {v['blocking']}")
        if v.get("join_flags"):
            print(f"     join risk: {v['join_flags']}  (join_risk_score={v['join_risk']})")

    summary = {}
    for v in graph_verdict(g):
        summary[v["decision"]] = summary.get(v["decision"], 0) + 1
    print(f"\nDecision summary: {json.dumps(summary)}")

    ingest(g, args.neo4j_uri, args.neo4j_user, args.neo4j_pass,
           dry_run=args.dry_run, out_path=args.cypher_out)

    if args.graph_only:
        print("\n--graph-only: stopped after building the knowledge graph.")
        return 0

    if args.rollup_out:
        import csv as _csv
        from .rollup import rollup_report
        rows = rollup_report(g)
        with open(args.rollup_out, "w", newline="") as f:
            w = _csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else [])
            w.writeheader()
            w.writerows(rows)
        print(f"\nWrote rollup report ({len(rows)} routines) to {args.rollup_out}")

    pyspark = generate_pyspark(g, scores, include_all=args.pyspark_all)
    if args.pyspark_out:
        with open(args.pyspark_out, "w") as f:
            f.write(pyspark)
        print(f"\nWrote generated PySpark to {args.pyspark_out}")

    if args.validate_out:
        validation = generate_validation(g, scores)
        with open(args.validate_out, "w") as f:
            f.write(validation)
        print(f"Wrote post-migration validation script to {args.validate_out}")

    if args.pipeline_out or args.driver_out:
        from .pipeline import build_execution_plan, write_plan, write_driver
        mod = "out_pyspark"
        if args.pyspark_out:
            import os as _os
            mod = _os.path.splitext(_os.path.basename(args.pyspark_out))[0]
        plan = build_execution_plan(g, pyspark_module=mod)
        print(f"\nExecution plan: {plan['summary']['steps']} step(s) "
              f"{plan['summary']['by_engine']}, "
              f"{plan['summary']['cross_engine_handoffs']} cross-engine hand-off(s)")
        if args.pipeline_out:
            write_plan(plan, args.pipeline_out)
            print(f"Wrote execution plan to {args.pipeline_out}")
        if args.driver_out:
            write_driver(args.driver_out)
            print(f"Wrote runnable driver to {args.driver_out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
