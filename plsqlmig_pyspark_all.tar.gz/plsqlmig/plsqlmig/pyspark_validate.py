"""
Post-migration validation generator.

Answers the other half of "did the conversion work": pyspark_gen.py produces
the PySpark job; this produces a companion script that checks its output
against the Oracle source it was migrated from, for every table a
CONVERT_TO_PYSPARK or REWRITE_FOR_PYSPARK routine writes.

Each table gets three checks:
  - schema      : same column set on both sides (catches silent schema drift)
  - row_count   : same number of rows on both sides
  - checksum    : an order-independent, per-row hash summed across the table,
                  so the two sides matching is strong evidence the data itself
                  (not just the row count) came out the same

This produces a runnable reference script, not a guaranteed-correct one: the
two reader classes have real connections commented out (same convention as
pipeline.py's driver template) for you to fill in, and the column list per
table is a best-effort pull from the columns referenced in the write
statement -- review it before relying on the checksum.
"""
from __future__ import annotations

from typing import Dict, List, Set

from .graph_model import Graph
from .scorer import UnitScore

_VALIDATED_DECISIONS = ("CONVERT_TO_PYSPARK", "REWRITE_FOR_PYSPARK")


def _tables_written(g: Graph, routine_id: str) -> Dict[str, Set[str]]:
    """Table name -> columns referenced in the statement(s) that write it."""
    frontier = [e.dst for e in g.edges if e.src == routine_id and e.rel == "HAS_BLOCK"]
    seen: Set[str] = set()
    stmts: Set[str] = set()
    while frontier:
        b = frontier.pop()
        if b in seen:
            continue
        seen.add(b)
        for e in g.edges:
            if e.src != b:
                continue
            if e.rel == "EXECUTES":
                stmts.add(e.dst)
            elif e.rel == "CONTAINS":
                d = g.nodes.get(e.dst)
                if d and d.label in ("Block", "Loop", "Branch"):
                    frontier.append(e.dst)

    out: Dict[str, Set[str]] = {}
    for st in stmts:
        writes = [g.nodes[w.dst].props.get("name", "")
                 for w in g.edges if w.src == st and w.rel == "WRITES"]
        if not writes:
            continue
        cols = {g.nodes[c.dst].props.get("name", "")
               for c in g.edges if c.src == st and c.rel == "REFERENCES"}
        for t in writes:
            if t:
                out.setdefault(t, set()).update(c for c in cols if c)
    return out


def generate_validation(g: Graph, scores: List[UnitScore]) -> str:
    """Emit a runnable validation script for every table a convertible routine writes."""
    decisions = {e.src: g.nodes[e.dst].props.get("decision")
                 for e in g.edges if e.rel == "ASSESSED_AS"}

    entries: List[dict] = []
    seen_tables: Set[str] = set()
    for node in g.nodes.values():
        if node.label not in ("Procedure", "Function"):
            continue
        decision = decisions.get(node.id)
        if decision not in _VALIDATED_DECISIONS:
            continue
        owner = node.props.get("owner", "")
        name = node.props.get("name", "")
        routine_label = f"{owner}.{name}" if owner else name
        for table, cols in sorted(_tables_written(g, node.id).items()):
            if table in seen_tables:
                continue
            seen_tables.add(table)
            entries.append({
                "table": table,
                "source_routine": routine_label,
                "decision": decision,
                "columns": sorted(c for c in cols if c) or ["<list columns to checksum here>"],
            })

    tables_literal = "[\n" + "".join(
        f"    {{'table': {e['table']!r}, 'source_routine': {e['source_routine']!r}, "
        f"'decision': {e['decision']!r}, 'columns': {e['columns']!r}}},\n"
        for e in entries
    ) + "]"

    return _VALIDATION_TEMPLATE.replace("__TABLES__", tables_literal)


def write_validation(script: str, path: str) -> None:
    with open(path, "w") as f:
        f.write(script)


_VALIDATION_TEMPLATE = '''#!/usr/bin/env python3
"""Auto-generated post-migration validation harness.

Compares each table a converted/rewritten routine writes, on Oracle (the
source of truth) against PySpark (the migrated output), so you can confirm
the conversion produced the same data before cutting over.

For every table this checks:
  - schema     : same column set on both sides (catches silent schema drift)
  - row_count  : same number of rows on both sides
  - checksum   : an order-independent, per-row hash summed across the table --
                 matching is strong evidence the data itself, not just the row
                 count, came out the same

Fill in OracleReader/SparkReader below with your real connections, review the
column list per table (it is a best-effort pull from the source SQL, not a
guarantee), then run:

    python out_validate.py
"""
import sys
from dataclasses import dataclass, field
from typing import List


@dataclass
class ValidationResult:
    table: str
    check: str
    passed: bool
    detail: str = ""


class OracleReader:
    """Reads validation aggregates from the Oracle source table."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.conn = None
        # import oracledb
        # self.conn = oracledb.connect(
        #     user=cfg["user"], password=cfg["password"], dsn=cfg["dsn"])

    def row_count(self, table: str) -> int:
        # cur = self.conn.cursor()
        # cur.execute(f"SELECT COUNT(*) FROM {table}")
        # return cur.fetchone()[0]
        raise NotImplementedError("wire up an Oracle connection in OracleReader")

    def checksum(self, table: str, columns: List[str]) -> int:
        # ORA_HASH is a per-row hash; SUM() makes the comparison
        # order-independent so row ordering differences don't cause a
        # false mismatch.
        # cur = self.conn.cursor()
        # cols = " || '|' || ".join(f"NVL(TO_CHAR({c}), '')" for c in columns)
        # cur.execute(f"SELECT SUM(ORA_HASH({cols})) FROM {table}")
        # return cur.fetchone()[0] or 0
        raise NotImplementedError("wire up an Oracle connection in OracleReader")

    def columns(self, table: str) -> List[str]:
        # cur = self.conn.cursor()
        # cur.execute(
        #     "SELECT column_name FROM all_tab_columns WHERE table_name = UPPER(:t)",
        #     t=table)
        # return sorted(r[0].lower() for r in cur.fetchall())
        raise NotImplementedError("wire up an Oracle connection in OracleReader")


class SparkReader:
    """Reads the same aggregates from the Spark/PySpark-migrated table."""

    def __init__(self, spark):
        self.spark = spark

    def row_count(self, table: str) -> int:
        return self.spark.table(table).count()

    def checksum(self, table: str, columns: List[str]) -> int:
        from pyspark.sql import functions as F
        df = self.spark.table(table).select(*columns)
        row_hash = F.xxhash64(*[F.coalesce(F.col(c).cast("string"), F.lit("")) for c in columns])
        total = df.select(F.sum(row_hash)).first()[0]
        return int(total or 0)

    def columns(self, table: str) -> List[str]:
        return sorted(c.lower() for c in self.spark.table(table).columns)


# One entry per table written by a CONVERT_TO_PYSPARK / REWRITE_FOR_PYSPARK
# routine. `columns` is a best-effort list pulled from the source SQL --
# review it (especially for REWRITE routines, where the migrated logic may
# not map 1:1 to the original statement) before trusting the checksum.
TABLES = __TABLES__


def validate_table(oracle: OracleReader, spark: SparkReader,
                   table: str, columns: List[str]) -> List[ValidationResult]:
    results: List[ValidationResult] = []
    try:
        ora_cols, spark_cols = oracle.columns(table), spark.columns(table)
    except NotImplementedError as exc:
        return [ValidationResult(table, "schema", False, str(exc))]
    results.append(ValidationResult(
        table, "schema", ora_cols == spark_cols,
        "" if ora_cols == spark_cols else f"oracle={ora_cols} spark={spark_cols}"))

    ora_count, spark_count = oracle.row_count(table), spark.row_count(table)
    results.append(ValidationResult(
        table, "row_count", ora_count == spark_count,
        f"oracle={ora_count} spark={spark_count}"))

    ora_sum = oracle.checksum(table, columns)
    spark_sum = spark.checksum(table, columns)
    results.append(ValidationResult(
        table, "checksum", ora_sum == spark_sum,
        f"oracle={ora_sum} spark={spark_sum}"))
    return results


def main() -> int:
    oracle = OracleReader({"dsn": "", "user": "", "password": ""})

    from pyspark.sql import SparkSession
    spark_session = (SparkSession.builder.appName("plsql_migration_validate")
                     .enableHiveSupport().getOrCreate())
    spark = SparkReader(spark_session)

    all_results: List[ValidationResult] = []
    for t in TABLES:
        print(f"Validating {t['table']}  (from {t['source_routine']}, {t['decision']})")
        try:
            results = validate_table(oracle, spark, t["table"], t["columns"])
        except Exception as exc:                          # noqa: BLE001
            print(f"  ERROR: {exc}")
            all_results.append(ValidationResult(t["table"], "error", False, str(exc)))
            continue
        for r in results:
            status = "PASS" if r.passed else "FAIL"
            print(f"  [{status}] {r.check}" + (f"  ({r.detail})" if r.detail else ""))
        all_results.extend(results)

    failed = [r for r in all_results if not r.passed]
    print(f"\\n{len(all_results) - len(failed)}/{len(all_results)} checks passed.")
    if failed:
        print("FAILED:")
        for r in failed:
            print(f"  - {r.table}: {r.check}  {r.detail}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
'''
