"""
SQL statement analyzer built on sqlglot.

For each DML/query statement found by the structural parser, this:
  - identifies tables read vs written,
  - extracts set-based signals (joins, aggregates, window funcs, group by),
  - flags Oracle-specific constructs that complicate Spark migration,
  - attempts an Oracle -> Spark SQL transpile.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional

import sqlglot
from sqlglot import exp


@dataclass
class StmtAnalysis:
    kind: str
    reads: Set[str] = field(default_factory=set)
    writes: Set[str] = field(default_factory=set)
    columns: Set[str] = field(default_factory=set)
    joins: int = 0
    aggregates: int = 0
    window_funcs: int = 0
    has_group_by: bool = False
    operations: List[str] = field(default_factory=list)
    oracle_specific: List[str] = field(default_factory=list)
    spark_sql: Optional[str] = None
    parse_ok: bool = True
    # Join-type breakdown (join_type -> count), e.g. {"inner_join": 1, "left_outer_join": 1}.
    # Previously only a flat `joins` count reached the graph; this is what lets the
    # scorer/knowledge layer tell a plain inner join apart from a cross join or a
    # non-equi join, which carry very different migration risk.
    join_kinds: Dict[str, int] = field(default_factory=dict)
    join_risk_score: float = 0.0
    has_cross_join: bool = False
    has_outer_join: bool = False
    has_non_equi_join: bool = False


# Oracle constructs that don't map cleanly to Spark SQL.
_ORACLE_FLAGS = {
    exp.Connect: "connect_by_hierarchical",
}
_ORACLE_FUNC_NAMES = {"SYS_GUID", "NVL2", "ROWNUM", "ROWID"}

# Weight per join type, used to score how much a statement's join composition
# actually parallelizes cleanly in Spark. 1.0 = a plain inner/equi join
# (baseline complexity). Outer joins are still directly expressible in Spark
# but need null-aware downstream logic, so they cost a little more; cross
# joins and non-equi joins are the ones that most often need a rewrite (an
# accidental cartesian product, or a broadcast/range join tuned by hand)
# rather than a mechanical translation, so they cost the most.
JOIN_TYPE_WEIGHTS: Dict[str, float] = {
    "inner_join":       1.0,
    "semi_join":        1.0,
    "anti_join":        1.0,
    "left_outer_join":  1.2,
    "right_outer_join": 1.2,
    "full_outer_join":  1.5,
    "cross_join":       2.5,
    "non_equi_join":    2.0,
}


def _table_name(t: exp.Table) -> str:
    return ".".join(p.name for p in [t.args.get("db"), t.this] if p).lower() or t.name.lower()


def _join_type(j: exp.Join) -> str:
    side = str(j.args.get("side") or "").upper()
    kind = str(j.args.get("kind") or "").upper()
    on = j.args.get("on")
    using = j.args.get("using")
    if kind == "CROSS" or (on is None and not using):
        return "cross_join"
    if kind == "SEMI":
        return "semi_join"
    if kind == "ANTI":
        return "anti_join"
    if side == "LEFT":
        return "left_outer_join"
    if side == "RIGHT":
        return "right_outer_join"
    if side == "FULL":
        return "full_outer_join"
    return "inner_join"


def analyze_statement(sql_text: str) -> StmtAnalysis:
    kind = sql_text.split(None, 1)[0].upper()
    a = StmtAnalysis(kind=kind)

    try:
        tree = sqlglot.parse_one(sql_text, read="oracle")
    except Exception:
        a.parse_ok = False
        return a
    if tree is None:
        a.parse_ok = False
        return a

    # Writes: the target of INSERT/UPDATE/DELETE/MERGE.
    write_target = None
    if isinstance(tree, (exp.Insert, exp.Update, exp.Delete, exp.Merge)):
        this = tree.this
        if isinstance(this, exp.Schema):     # INSERT INTO t (cols)
            this = this.this
        if isinstance(this, exp.Table):
            write_target = this
            a.writes.add(_table_name(this))

    # Reads: every other table reference.
    for t in tree.find_all(exp.Table):
        if write_target is not None and t is write_target:
            continue
        a.reads.add(_table_name(t))

    # Set-based signals.
    a.joins = len(list(tree.find_all(exp.Join)))
    a.window_funcs = len(list(tree.find_all(exp.Window)))
    a.has_group_by = tree.find(exp.Group) is not None
    a.aggregates = len(
        [f for f in tree.find_all(exp.AggFunc)]
    )

    # Database operations (typed) for the DBOperation nodes / scorer weights.
    for j in tree.find_all(exp.Join):
        jt = _join_type(j)
        a.operations.append(jt)
        a.join_kinds[jt] = a.join_kinds.get(jt, 0) + 1
        a.join_risk_score += JOIN_TYPE_WEIGHTS.get(jt, 1.0)
        on = j.args.get("on")
        if on is not None and j.find(exp.EQ) is None:
            a.operations.append("non_equi_join")
            a.join_kinds["non_equi_join"] = a.join_kinds.get("non_equi_join", 0) + 1
            a.join_risk_score += JOIN_TYPE_WEIGHTS.get("non_equi_join", 1.0)
            a.has_non_equi_join = True
    a.has_cross_join = a.join_kinds.get("cross_join", 0) > 0
    a.has_outer_join = any(a.join_kinds.get(k) for k in
                           ("left_outer_join", "right_outer_join", "full_outer_join"))
    if isinstance(tree, exp.Insert):
        a.operations.append("set_insert" if tree.find(exp.Select) else "insert")
    elif isinstance(tree, exp.Update):
        a.operations.append("set_update")
    elif isinstance(tree, exp.Delete):
        a.operations.append("set_delete")
    elif isinstance(tree, exp.Merge):
        a.operations.append("merge")
    if a.has_group_by or a.aggregates:
        a.operations.append("aggregate")
    if a.window_funcs:
        a.operations.append("window")
    if tree.find(exp.Union):
        a.operations.append("union")
    if tree.find(exp.Distinct):
        a.operations.append("distinct")

    # Referenced columns (capped to keep the graph readable).
    for col in tree.find_all(exp.Column):
        if col.name and col.name != "*":
            a.columns.add(col.name.lower())
        if len(a.columns) >= 25:
            break

    # Oracle-specific flags.
    for node_type, label in _ORACLE_FLAGS.items():
        if tree.find(node_type) is not None:
            a.oracle_specific.append(label)
    for fn in tree.find_all(exp.Anonymous):
        if fn.name and fn.name.upper() in _ORACLE_FUNC_NAMES:
            a.oracle_specific.append(f"oracle_func:{fn.name.upper()}")
    if "NEXTVAL" in sql_text.upper() or "CURRVAL" in sql_text.upper():
        a.oracle_specific.append("sequence_ref")

    # Transpile to Spark SQL (best effort).
    try:
        a.spark_sql = sqlglot.transpile(sql_text, read="oracle", write="spark")[0]
    except Exception:
        a.spark_sql = None

    return a
