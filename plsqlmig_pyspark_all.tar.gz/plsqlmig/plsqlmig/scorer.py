"""
Migration suitability scorer.

Each procedure/function is scored on two axes:
  set_based_score  -> how much the logic is bulk/parallel data transformation
  oracle_lock_score -> how much it depends on Oracle procedural/transactional/OLTP behavior

Decision:
  high set-based, low lock          -> CONVERT_TO_PYSPARK
  high set-based, high lock         -> REWRITE_FOR_PYSPARK (redesign procedural parts)
  low set-based  (procedural/OLTP)  -> KEEP_IN_ORACLE

Weights are intentionally explicit and easy to tune; they encode engineering
judgement, not ground truth. Treat the output as a triage signal that a human
reviews, not an automatic decision.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from .graph_model import Graph


# Procedural features that pull toward "keep in Oracle".
LOCK_WEIGHTS: Dict[str, float] = {
    "cursor_for_loop":   3.0,   # row-by-row processing
    "explicit_cursor":   2.0,
    "while_loop":        2.0,
    "sequence_nextval":  3.0,   # identity/sequence dependence
    "autonomous_txn":    4.0,   # transaction semantics with no Spark analog
    "savepoint":         3.0,
    "dbms_pkg_call":     3.0,   # DBMS_* has no Spark equivalent
    "utl_pkg_call":      3.0,
    "raise_app_error":   1.0,
    "exception_handler": 1.0,
    "rollback":          1.5,
    "connect_by":        2.0,
}

# Per-statement set-based signal weights.
SET_WEIGHTS = {
    "join": 1.0,
    "aggregate": 1.5,
    "window": 2.0,
    "group_by": 1.5,
    "bulk_dml": 2.0,            # INSERT...SELECT / MERGE / CTAS style
}


@dataclass
class UnitScore:
    name: str
    owner: str
    set_based_score: float = 0.0
    oracle_lock_score: float = 0.0
    call_count: int = 0
    decision: str = ""
    rationale: List[str] = field(default_factory=list)
    # Join types this routine's statements use that need a closer look before
    # calling the conversion clean (cross join, non-equi join, full outer join).
    # Populated from each statement's join_types property; consumed by the
    # knowledge layer to keep confidence honest even on an otherwise clean verdict.
    join_flags: List[str] = field(default_factory=list)


def _bulk_dml(stmt_props: dict) -> bool:
    kind = stmt_props.get("kind", "")
    if kind == "MERGE":
        return True
    if kind == "INSERT" and (stmt_props.get("joins") or stmt_props.get("has_group_by")):
        return True
    return False


def score_graph(g: Graph) -> List[UnitScore]:
    scores: List[UnitScore] = []

    for node in g.nodes.values():
        if node.label not in ("Procedure", "Function"):
            continue
        us = UnitScore(name=node.props.get("name", "?"),
                       owner=node.props.get("owner", ""))

        # Statements hang off the routine's body Block(s): routine -HAS_BLOCK-> block -EXECUTES-> stmt
        block_ids = {e.dst for e in g.edges if e.src == node.id and e.rel == "HAS_BLOCK"}
        stmt_ids = {e.dst for e in g.edges
                    if e.src in block_ids and e.rel == "EXECUTES"}

        # Lock score from HAS_FEATURE edges; calls from CALLS.
        for e in g.edges:
            if e.src != node.id:
                continue
            if e.rel == "HAS_FEATURE":
                feat = g.nodes[e.dst].props.get("name", "")
                w = LOCK_WEIGHTS.get(feat, 0.0)
                if w:
                    cnt = e.props.get("count", 1)
                    us.oracle_lock_score += w * min(cnt, 3)
                    us.rationale.append(f"-Oracle: {feat} x{cnt} (+{w*min(cnt,3):.1f})")
            elif e.rel == "CALLS":
                us.call_count += 1

        for sid in stmt_ids:
            sp = g.nodes[sid].props
            if sp.get("joins"):
                # join_risk_score is the join-type-weighted score (inner/equi
                # joins at baseline weight, outer/cross/non-equi joins weighted
                # higher). Fall back to a flat per-join weight for statements
                # analyzed before this breakdown existed.
                us.set_based_score += SET_WEIGHTS["join"] * sp.get(
                    "join_risk_score", sp["joins"])
                if sp.get("has_cross_join"):
                    us.join_flags.append("cross_join")
                    us.rationale.append(
                        "+SetBased: cross join present — confirm this is intentional "
                        "before converting; an accidental cartesian product is a common "
                        "correctness/perf bug after migration")
                if sp.get("has_non_equi_join"):
                    us.join_flags.append("non_equi_join")
                    us.rationale.append(
                        "+SetBased: non-equi join present — will likely need a Spark "
                        "broadcast or range-partition hint to perform well")
                if sp.get("has_outer_join"):
                    us.join_flags.append("outer_join")
            if sp.get("aggregates"):
                us.set_based_score += SET_WEIGHTS["aggregate"]
            if sp.get("window_funcs"):
                us.set_based_score += SET_WEIGHTS["window"] * sp["window_funcs"]
            if sp.get("has_group_by"):
                us.set_based_score += SET_WEIGHTS["group_by"]
            if _bulk_dml(sp):
                us.set_based_score += SET_WEIGHTS["bulk_dml"]
                us.rationale.append(f"+SetBased: bulk {sp.get('kind')} statement")
            if sp.get("oracle_specific"):
                us.oracle_lock_score += 1.5
                us.rationale.append(f"-Oracle: {sp['oracle_specific']}")

        us.join_flags = sorted(set(us.join_flags))

        us.decision = _decide(us.set_based_score, us.oracle_lock_score, us.call_count)
        if us.decision == "ORCHESTRATION":
            us.rationale.insert(0, f"+Orchestration: invokes {us.call_count} routine(s)")
        scores.append(us)

    return scores


def _decide(set_based: float, lock: float, calls: int = 0) -> str:
    # A unit that mostly calls other routines and does little data work is an
    # orchestrator: in Spark it becomes the driver / DAG, not a transform.
    if set_based < 2.0 and calls >= 2:
        return "ORCHESTRATION"
    if set_based < 2.0:
        return "KEEP_IN_ORACLE"        # not really a data-transform workload
    if lock <= 3.0:
        return "CONVERT_TO_PYSPARK"    # clean set-based logic
    if set_based >= lock:
        return "REWRITE_FOR_PYSPARK"   # transformable but procedural baggage
    return "KEEP_IN_ORACLE"
