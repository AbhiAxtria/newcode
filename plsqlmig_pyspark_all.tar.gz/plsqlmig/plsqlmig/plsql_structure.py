"""
Structural PL/SQL parser.

This is the lightweight, dependency-free front end. It carves a .sql file into
top-level objects (package / package body / procedure / function / trigger),
finds the procedures and functions inside a package body, and extracts the
procedural feature signals the scorer needs.

PRODUCTION UPGRADE PATH
-----------------------
Replace the regex object splitting here with an ANTLR4 parse using the PL/SQL
grammar from antlr/grammars-v4 (sql/plsql). The rest of the pipeline
(graph_builder, neo4j_store, scorer, pyspark_gen) consumes the dataclasses
below, so swapping the front end does not ripple downstream: have the ANTLR
listener emit the same PlsqlObject / PlsqlUnit objects.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Dict


# Feature patterns -> regex. These run against a unit's source text.
FEATURE_PATTERNS: Dict[str, str] = {
    "cursor_for_loop":   r"\bFOR\b\s+\w+\s+IN\s+(?:\w+\b|\()",
    "explicit_cursor":   r"\bCURSOR\b\s+\w+",
    "while_loop":        r"\bWHILE\b\s+.+?\bLOOP\b",
    "basic_loop":        r"(?<!END\s)\bLOOP\b",
    "sequence_nextval":  r"\.\s*NEXTVAL\b",
    "autonomous_txn":    r"PRAGMA\s+AUTONOMOUS_TRANSACTION",
    "commit":            r"\bCOMMIT\b",
    "rollback":          r"\bROLLBACK\b",
    "savepoint":         r"\bSAVEPOINT\b",
    "exception_handler": r"\bEXCEPTION\b\s+WHEN\b",
    "dbms_pkg_call":     r"\bDBMS_\w+\s*\.",
    "utl_pkg_call":      r"\bUTL_\w+\s*\.",
    "connect_by":        r"\bCONNECT\s+BY\b",
    "bulk_collect":      r"\bBULK\s+COLLECT\b",
    "if_branch":         r"\bIF\b\s+.+?\bTHEN\b",
    "raise_app_error":   r"RAISE_APPLICATION_ERROR",
    "execute_immediate": r"\bEXECUTE\s+IMMEDIATE\b",
}

# DML / query statements we hand to sqlglot for fine-grained analysis.
_DML_RE = re.compile(
    r"(?is)\b(INSERT\b.*?|UPDATE\b.*?|DELETE\b.*?|MERGE\b.*?|SELECT\b.*?)(?=;)"
)

# Dynamic DDL inside EXECUTE IMMEDIATE string literals, e.g.
#   EXECUTE IMMEDIATE 'truncate table AR_BALANCE';
_DYNAMIC_DDL_RE = re.compile(
    r"(?is)EXECUTE\s+IMMEDIATE\s+'\s*(truncate\s+table|drop\s+table|create\s+table)\s+([\w\.]+)"
)

# Keywords that look like calls but aren't user procedure invocations.
_CALL_STOP = {
    "BEGIN", "END", "IF", "ELSIF", "ELSE", "LOOP", "WHILE", "FOR", "EXIT",
    "COMMIT", "ROLLBACK", "RETURN", "NULL", "EXCEPTION", "WHEN", "RAISE",
    "CASE", "THEN", "EXECUTE", "DELETE", "INSERT", "UPDATE", "SELECT",
    "MERGE", "OPEN", "CLOSE", "FETCH", "SAVEPOINT", "GOTO", "CONTINUE",
    "RAISE_APPLICATION_ERROR", "DECLARE", "SET", "VALUES", "INTO",
}

# A procedure invocation as a *statement*: `name;` or `name(...);` at line start.
# Requiring the trailing `;` (and `)` for the arg form) excludes SQL functions
# used mid-expression, e.g. SUM(x) AS total — which never end in `);`.
_CALL_NOARG_RE = re.compile(r"(?im)^\s*([a-z]\w*)\s*;")
_CALL_ARGS_RE = re.compile(r"(?im)^\s*([a-z]\w*)\s*\([^;]*\)\s*;")

# Declaration-section patterns.
_CURSOR_DECL_RE = re.compile(r"(?is)\bCURSOR\s+(\w+).*?;")
_CONST_DECL_RE = re.compile(r"(?im)^\s*(\w+)\s+CONSTANT\s+([\w()\s,]+?)\s*(?::=|;)")
_VAR_DECL_RE = re.compile(r"(?im)^\s*(\w+)\s+([A-Za-z][\w%.]*(?:\s*\([\d,\s]*\))?)\s*(?::=[^;]*)?;")
_PRAGMA_RE = re.compile(r"(?im)^\s*PRAGMA\b[^;]*;")

_OBJECT_RE = re.compile(
    r"(?is)CREATE\s+(?:OR\s+REPLACE\s+)?"
    r"(?P<kind>PACKAGE\s+BODY|PACKAGE|PROCEDURE|FUNCTION|TRIGGER)\s+"
    r"(?P<name>[\w\.\"]+)"
)

# Procedures / functions declared inside a package body.
_UNIT_RE = re.compile(
    r"(?is)\b(?P<kind>PROCEDURE|FUNCTION)\s+(?P<name>\w+)\b"
)


@dataclass
class SqlStmt:
    kind: str                 # SELECT / INSERT / UPDATE / DELETE / MERGE
    text: str


@dataclass
class Symbol:
    name: str
    kind: str                 # PARAMETER | VARIABLE | CONSTANT | CURSOR
    datatype: str = ""
    mode: str = ""            # IN / OUT / IN OUT (parameters only)


@dataclass
class PlsqlUnit:
    """A procedure or function (standalone, or nested in a package body)."""
    kind: str                 # PROCEDURE | FUNCTION
    name: str
    source: str
    features: Dict[str, int] = field(default_factory=dict)
    statements: List[SqlStmt] = field(default_factory=list)
    calls: List[str] = field(default_factory=list)          # invoked routine names
    dynamic_writes: List[str] = field(default_factory=list)  # tables hit via EXECUTE IMMEDIATE
    symbols: List[Symbol] = field(default_factory=list)      # params, vars, consts, cursors


@dataclass
class PlsqlObject:
    """A top-level CREATE object."""
    kind: str                 # PACKAGE | PACKAGE BODY | PROCEDURE | FUNCTION | TRIGGER
    name: str
    source: str
    units: List[PlsqlUnit] = field(default_factory=list)


_LINE_COMMENT = re.compile(r"--[^\n]*")
_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)


def _strip_comments(text: str) -> str:
    text = _BLOCK_COMMENT.sub(" ", text)
    text = _LINE_COMMENT.sub(" ", text)
    return text


def _count_features(text: str) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for feat, pat in FEATURE_PATTERNS.items():
        n = len(re.findall(pat, text, flags=re.IGNORECASE | re.DOTALL))
        if n:
            out[feat] = n
    return out


def _extract_statements(text: str) -> List[SqlStmt]:
    stmts: List[SqlStmt] = []
    for m in _DML_RE.finditer(text):
        raw = m.group(1).strip()
        kind = raw.split(None, 1)[0].upper()
        stmts.append(SqlStmt(kind=kind, text=raw))
    return stmts


def _extract_dynamic_writes(text: str) -> List[str]:
    out = []
    for verb, tbl in _DYNAMIC_DDL_RE.findall(text):
        out.append(tbl.lower())
    return out


def _split_routine(source: str, name: str):
    """Return (signature, declaration_section) for one routine source."""
    m_name = re.search(rf"(?is)\b{re.escape(name)}\b", source)
    after = source[m_name.end():] if m_name else source
    sig = ""
    m_sig = re.match(r"(?is)\s*\((.*?)\)\s*(?:RETURN\b|IS\b|AS\b)", after)
    if m_sig:
        sig = m_sig.group(1)
    m_is = re.search(r"(?is)\b(IS|AS)\b", after)
    m_begin = re.search(r"(?is)\bBEGIN\b", after)
    decl = ""
    if m_is and m_begin and m_begin.start() > m_is.end():
        decl = after[m_is.end():m_begin.start()]
    return sig, decl


def _parse_params(sig: str) -> List[Symbol]:
    if not sig.strip():
        return []
    params: List[Symbol] = []
    for raw in re.split(r",(?![^()]*\))", sig):
        raw = raw.strip()
        if not raw:
            continue
        m = re.match(r"(?is)(\w+)\s+(IN\s+OUT|IN|OUT)?\s*([\w%.]+(?:\([\d,\s]*\))?)", raw)
        if m:
            params.append(Symbol(name=m.group(1), kind="PARAMETER",
                                 mode=(m.group(2) or "IN").upper().replace("  ", " "),
                                 datatype=m.group(3) or ""))
    return params


def _parse_declarations(decl: str) -> List[Symbol]:
    syms: List[Symbol] = []
    for m in _CURSOR_DECL_RE.finditer(decl):
        syms.append(Symbol(name=m.group(1), kind="CURSOR"))
    work = _CURSOR_DECL_RE.sub(" ", decl)
    work = _PRAGMA_RE.sub(" ", work)
    consts = set()
    for m in _CONST_DECL_RE.finditer(work):
        consts.add(m.group(1).lower())
        syms.append(Symbol(name=m.group(1), kind="CONSTANT", datatype=m.group(2).strip()))
    for m in _VAR_DECL_RE.finditer(work):
        nm, dt = m.group(1), m.group(2).strip()
        if nm.lower() in consts or dt.upper() == "CONSTANT":
            continue
        syms.append(Symbol(name=nm, kind="VARIABLE", datatype=dt))
    return syms


def _extract_symbols(source: str, name: str) -> List[Symbol]:
    sig, decl = _split_routine(source, name)
    return _parse_params(sig) + _parse_declarations(decl)


def _extract_calls(text: str, own_name: str) -> List[str]:
    # Remove SQL statement bodies first so SQL keywords (USING, ON, SUM ...)
    # inside them can't be mistaken for procedure calls.
    text = _DML_RE.sub(lambda m: " " * len(m.group(0)), text)
    calls = []
    for rx in (_CALL_NOARG_RE, _CALL_ARGS_RE):
        for tok in rx.findall(text):
            up = tok.upper()
            if up in _CALL_STOP:
                continue
            if tok.lower() == own_name.lower():   # skip the header line itself
                continue
            calls.append(tok)
    # de-dup, preserve order
    seen, ordered = set(), []
    for c in calls:
        k = c.lower()
        if k not in seen:
            seen.add(k)
            ordered.append(c)
    return ordered


def _split_units(body: str) -> List[PlsqlUnit]:
    """Split a package body into its procedures/functions by their headers."""
    headers = list(_UNIT_RE.finditer(body))
    units: List[PlsqlUnit] = []
    for i, h in enumerate(headers):
        start = h.start()
        end = headers[i + 1].start() if i + 1 < len(headers) else len(body)
        src = body[start:end]
        units.append(
            PlsqlUnit(
                kind=h.group("kind").upper(),
                name=h.group("name"),
                source=src,
                features=_count_features(src),
                statements=_extract_statements(src),
                calls=_extract_calls(src, h.group("name")),
                dynamic_writes=_extract_dynamic_writes(src),
                symbols=_extract_symbols(src, h.group("name")),
            )
        )
    return units


def parse_source(sql_text: str) -> List[PlsqlObject]:
    """Parse a full .sql file into structured PL/SQL objects."""
    sql_text = _strip_comments(sql_text)
    matches = list(_OBJECT_RE.finditer(sql_text))
    objects: List[PlsqlObject] = []
    for i, m in enumerate(matches):
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(sql_text)
        src = sql_text[start:end]
        kind = re.sub(r"\s+", " ", m.group("kind").upper())
        name = m.group("name").strip('"')

        obj = PlsqlObject(kind=kind, name=name, source=src)

        if kind in ("PACKAGE BODY",):
            obj.units = _split_units(src)
        elif kind in ("PROCEDURE", "FUNCTION", "TRIGGER"):
            obj.units = [
                PlsqlUnit(
                    kind=kind if kind != "TRIGGER" else "PROCEDURE",
                    name=name,
                    source=src,
                    features=_count_features(src),
                    statements=_extract_statements(src),
                    calls=_extract_calls(src, name),
                    dynamic_writes=_extract_dynamic_writes(src),
                    symbols=_extract_symbols(src, name),
                )
            ]
        # PACKAGE (spec) has no executable body; skipped for unit extraction.
        objects.append(obj)
    return objects
