"""
Neo4j ingestion.

Writes the information graph using MERGE so re-runs are idempotent. Use
dry_run=True to emit Cypher to a file/stdout without a live database (useful
for review or when Neo4j isn't reachable yet).

Suggested constraints (run once in the DB):
    CREATE CONSTRAINT IF NOT EXISTS FOR (n:Procedure) REQUIRE n.id IS UNIQUE;
    CREATE CONSTRAINT IF NOT EXISTS FOR (n:Table)     REQUIRE n.id IS UNIQUE;
"""
from __future__ import annotations

from typing import List, Optional

from .graph_model import Graph


def _props_to_cypher(props: dict) -> str:
    items = []
    for k, v in props.items():
        if isinstance(v, bool):
            items.append(f"{k}: {str(v).lower()}")
        elif isinstance(v, (int, float)):
            items.append(f"{k}: {v}")
        elif isinstance(v, (list, tuple)):
            parts = []
            for el in v:
                safe = str(el).replace("\\", "\\\\").replace("'", "\\'")
                parts.append(f"'{safe}'")
            items.append(f"{k}: [{', '.join(parts)}]")
        else:
            safe = str(v).replace("\\", "\\\\").replace("'", "\\'")
            items.append(f"{k}: '{safe}'")
    return ", ".join(items)


def graph_to_cypher(g: Graph) -> List[str]:
    from .schema import cypher_constraints, cypher_labels
    # Properties written only when the node is first created (never overwritten
    # on later runs), so re-ingesting a file updates the node instead of resetting it.
    CREATE_ONLY = {"created_at", "res_id"}
    stmts: List[str] = list(cypher_constraints())
    for n in g.nodes.values():
        all_props = {"id": n.id, **n.props}
        mutable = {k: v for k, v in all_props.items() if k not in CREATE_ONLY}
        labels = cypher_labels(n.label)          # e.g. ':Procedure:Node:Resource'
        # MERGE on the shared :Node label + id so the SAME logical object is reused
        # across files/runs regardless of which specific label it first got.
        stmts.append(
            f"MERGE (n:Node {{id: '{n.id}'}}) "
            f"ON CREATE SET n{labels}, n += {{{_props_to_cypher(all_props)}}} "
            f"ON MATCH SET n{labels}, n += {{{_props_to_cypher(mutable)}}};"
        )
    for e in g.edges:
        set_clause = f" SET r += {{{_props_to_cypher(e.props)}}}" if e.props else ""
        stmts.append(
            f"MATCH (a {{id: '{e.src}'}}), (b {{id: '{e.dst}'}}) "
            f"MERGE (a)-[r:{e.rel}]->(b){set_clause};"
        )
    return stmts


def ingest(g: Graph, uri: str, user: str, password: str,
           dry_run: bool = False, out_path: Optional[str] = None) -> None:
    cypher = graph_to_cypher(g)

    if dry_run:
        text = "\n".join(cypher)
        if out_path:
            with open(out_path, "w") as f:
                f.write(text + "\n")
            print(f"[dry-run] wrote {len(cypher)} Cypher statements to {out_path}")
        else:
            print(text)
        return

    from neo4j import GraphDatabase
    driver = GraphDatabase.driver(uri, auth=(user, password))
    with driver.session() as session:
        for stmt in cypher:
            session.run(stmt)
    driver.close()
    print(f"Ingested {len(g.nodes)} nodes and {len(g.edges)} edges into Neo4j.")
