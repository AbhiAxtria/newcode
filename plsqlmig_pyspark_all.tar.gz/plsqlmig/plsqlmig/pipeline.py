"""
Hybrid execution pipeline generator.

Turns the assessed graph (per-routine verdicts + READS/WRITES + CALLS) into:
  1. an ordered, engine-tagged execution plan (a neutral JSON manifest), and
  2. a runnable Python driver that executes the plan in dependency order,
     dispatching each step to Oracle or Spark, with checkpoint/resume.

The plan is the contract; the driver is a reference orchestrator. The same plan
can also be emitted to Airflow / Dagster / Databricks Workflows (see
emit_airflow_dag).

Ordering rule: a unit that READS a table runs after the unit that WRITES it
(write-before-read), with CALLS as a secondary ordering (callee before caller).
Tables written on one engine and read on the other are cross-engine hand-offs.
"""
from __future__ import annotations

import json
from typing import Dict, List, Set, Tuple

from .graph_model import Graph

# verdict -> execution engine
ENGINE = {
    "CONVERT_TO_PYSPARK": "spark",
    "REWRITE_FOR_PYSPARK": "spark",
    "KEEP_IN_ORACLE": "oracle",
    "ORCHESTRATION": "driver",
}


def _routine_io(g: Graph, routine_id: str) -> Tuple[Set[str], Set[str], Set[str]]:
    """Aggregate the tables a routine reads/writes and the routines it calls."""
    reads: Set[str] = set()
    writes: Set[str] = set()
    calls: Set[str] = set()
    # walk routine -> (HAS_BLOCK) -> Block -> (CONTAINS) -> Block/Loop/Branch ...
    #                 -> (EXECUTES) -> SqlStatement -> READS/WRITES -> Table
    frontier = [e.dst for e in g.edges if e.src == routine_id and e.rel == "HAS_BLOCK"]
    seen: Set[str] = set()
    stmts: Set[str] = set()
    while frontier:
        b = frontier.pop()
        if b in seen:
            continue
        seen.add(b)
        for e in g.edges:
            if e.src != b:
                continue
            if e.rel == "EXECUTES":
                stmts.add(e.dst)
            elif e.rel == "CONTAINS":
                d = g.nodes.get(e.dst)
                if d and d.label in ("Block", "Loop", "Branch"):
                    frontier.append(e.dst)
    for e in g.edges:
        if e.src in stmts and e.rel == "READS":
            n = g.nodes.get(e.dst)
            if n:
                reads.add(n.props.get("name", ""))
        elif e.src in stmts and e.rel == "WRITES":
            n = g.nodes.get(e.dst)
            if n:
                writes.add(n.props.get("name", ""))
        elif e.src == routine_id and e.rel == "CALLS":
            n = g.nodes.get(e.dst)
            if n:
                calls.add(n.props.get("name", ""))
    reads.discard("")
    writes.discard("")
    calls.discard("")
    return reads, writes, calls


def build_execution_plan(g: Graph, pyspark_module: str = "out_pyspark") -> dict:
    """Produce the ordered, engine-tagged execution plan for the whole corpus."""
    # 1) collect assessed routines as units
    units: Dict[str, dict] = {}
    name_to_id: Dict[str, str] = {}
    for e in g.edges:
        if e.rel != "ASSESSED_AS":
            continue
        rid = e.src
        rnode = g.nodes.get(rid)
        anode = g.nodes.get(e.dst)
        if not rnode or not anode:
            continue
        decision = anode.props.get("decision", "PROCEDURAL")
        reads, writes, calls = _routine_io(g, rid)
        name = rnode.props.get("qualified") or rnode.props.get("name", rid)
        units[rid] = {
            "id": rid,
            "name": name,
            "artifact": rnode.props.get("name", name).lower(),
            "decision": decision,
            "engine": ENGINE.get(decision, "oracle"),
            "reads": sorted(reads),
            "writes": sorted(writes),
            "calls": sorted(calls),
        }
        name_to_id[rnode.props.get("name", "").lower()] = rid

    # 2) dependencies: write-before-read, plus callee-before-caller
    writers: Dict[str, List[str]] = {}
    for uid, u in units.items():
        for t in u["writes"]:
            writers.setdefault(t, []).append(uid)
    deps: Dict[str, Set[str]] = {uid: set() for uid in units}
    for uid, u in units.items():
        for t in u["reads"]:
            for w in writers.get(t, []):
                if w != uid:
                    deps[uid].add(w)                      # reader depends on writer
        for c in u["calls"]:
            cid = name_to_id.get(c.lower())
            if cid and cid != uid:
                deps[uid].add(cid)                        # caller depends on callee

    # 3) topological sort (Kahn); stable by name, cycle-tolerant
    order: List[str] = []
    done: Set[str] = set()
    remaining = set(units)
    while remaining:
        ready = sorted((uid for uid in remaining if deps[uid] <= done),
                       key=lambda i: units[i]["name"])
        if not ready:                                     # cycle: break by name order
            ready = [sorted(remaining, key=lambda i: units[i]["name"])[0]]
        for uid in ready:
            order.append(uid)
            done.add(uid)
            remaining.discard(uid)

    # 4) hand-offs: table written on one engine, read on another
    engine_of = {uid: u["engine"] for uid, u in units.items()}
    reader_engines: Dict[str, Set[str]] = {}
    writer_engines: Dict[str, Set[str]] = {}
    for uid, u in units.items():
        for t in u["reads"]:
            reader_engines.setdefault(t, set()).add(u["engine"])
        for t in u["writes"]:
            writer_engines.setdefault(t, set()).add(u["engine"])
    handoffs = []
    for t in sorted(set(writer_engines) & set(reader_engines)):
        we, re_ = writer_engines[t], reader_engines[t]
        crosses = any(a != b for a in we for b in re_)
        if crosses:
            handoffs.append({"table": t, "written_by": sorted(we), "read_by": sorted(re_)})

    steps = []
    for pos, uid in enumerate(order, 1):
        u = units[uid]
        steps.append({
            "id": uid, "seq": pos, "name": u["name"], "artifact": u["artifact"],
            "decision": u["decision"], "engine": u["engine"],
            "reads": u["reads"], "writes": u["writes"], "calls": u["calls"],
            "depends_on_ids": sorted(deps[uid]),
            "depends_on": sorted(units[d]["name"] for d in deps[uid]),
        })
    return {
        "version": 1,
        "config": {
            "pyspark_module": pyspark_module,
            "oracle": {"dsn": "", "user": "", "password_env": "ORACLE_PASSWORD"},
        },
        "summary": {
            "steps": len(steps),
            "by_engine": {eng: sum(1 for s in steps if s["engine"] == eng)
                          for eng in ("spark", "oracle", "driver")},
            "cross_engine_handoffs": len(handoffs),
        },
        "handoffs": handoffs,
        "steps": steps,
    }


def write_plan(plan: dict, path: str) -> None:
    with open(path, "w") as f:
        json.dump(plan, f, indent=2)


DRIVER_TEMPLATE = '''#!/usr/bin/env python3
"""Auto-generated hybrid execution driver.

Runs the migrated pipeline (Oracle + PySpark steps) in dependency order with
checkpoint/resume. Fill in the two adapters with your real connections.

  PIPELINE_PLAN   path to the plan JSON        (default: pipeline.json)
  PIPELINE_STATE  path to the checkpoint file  (default: .pipeline_state.json)
"""
import json, os, sys

PLAN = os.environ.get("PIPELINE_PLAN", "pipeline.json")
STATE = os.environ.get("PIPELINE_STATE", ".pipeline_state.json")


def load_state():
    try:
        return set(json.load(open(STATE)).get("completed", []))
    except Exception:
        return set()


def save_state(done):
    json.dump({"completed": sorted(done)}, open(STATE, "w"), indent=2)


class OracleAdapter:
    """Runs a KEEP_IN_ORACLE unit by calling the stored procedure in Oracle."""
    def __init__(self, cfg):
        self.cfg = cfg
        self.conn = None
        # import oracledb
        # self.conn = oracledb.connect(
        #     user=cfg["oracle"]["user"],
        #     password=os.environ[cfg["oracle"]["password_env"]],
        #     dsn=cfg["oracle"]["dsn"])

    def run(self, step):
        proc = step["artifact"]
        # cur = self.conn.cursor(); cur.callproc(proc); self.conn.commit()
        print(f"    [oracle] CALL {proc}();  (reads={step['reads']} writes={step['writes']})")


class SparkAdapter:
    """Runs a CONVERT/REWRITE unit by calling its generated PySpark function."""
    def __init__(self, cfg, spark=None):
        self.cfg = cfg
        self.spark = spark
        # from pyspark.sql import SparkSession
        # self.spark = spark or SparkSession.builder.getOrCreate()
        # import importlib
        # self.mod = importlib.import_module(cfg["pyspark_module"])

    def run(self, step):
        fn = step["artifact"]
        # getattr(self.mod, fn)(self.spark)
        print(f"    [spark]  {self.cfg['pyspark_module']}.{fn}(spark)  (reads={step['reads']} writes={step['writes']})")


def main():
    plan = json.load(open(PLAN))
    cfg = plan["config"]
    oracle, spark = OracleAdapter(cfg), SparkAdapter(cfg)
    steps = plan["steps"]
    done = load_state()

    if plan["handoffs"]:
        print("Cross-engine hand-off tables (must be visible to both engines):")
        for h in plan["handoffs"]:
            print(f"  - {h['table']}  written_by={h['written_by']} read_by={h['read_by']}")
        print()

    made_progress = True
    while len(done) < len(steps) and made_progress:
        made_progress = False
        for s in steps:
            if s["id"] in done:
                continue
            if not all(d in done for d in s["depends_on_ids"]):
                continue
            print(f"==> [{s['seq']:>3}] [{s['engine']:<6}] {s['name']}  ({s['decision']})")
            eng = s["engine"]
            try:
                if eng == "oracle":
                    oracle.run(s)
                elif eng == "spark":
                    spark.run(s)
                else:
                    print(f"    [driver] orchestration unit; calls: {', '.join(s['calls']) or '-'}")
            except Exception as exc:                     # noqa: BLE001
                print(f"    FAILED: {exc}"); save_state(done); sys.exit(2)
            done.add(s["id"]); save_state(done); made_progress = True

    if len(done) < len(steps):
        blocked = [s["name"] for s in steps if s["id"] not in done]
        print("Blocked (unmet dependency or cycle):", blocked); sys.exit(1)
    print("\\nPipeline complete: all steps ran in dependency order.")


if __name__ == "__main__":
    main()
'''


def write_driver(path: str) -> None:
    with open(path, "w") as f:
        f.write(DRIVER_TEMPLATE)
