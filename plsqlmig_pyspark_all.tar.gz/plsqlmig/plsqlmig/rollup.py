"""
Resource-level rollups.

For every Procedure/Function, aggregate what lies BENEATH it -- its whole
transitive call subtree -- so that selecting one routine answers, at a glance:

  * how many routines it pulls in (and how deep)
  * how many tables / sequences those routines touch
  * how the migration verdicts break down across the subtree
    (e.g. "2 stay in Oracle, 2 convert to PySpark, 1 needs a rewrite")

The result is written onto each routine node as scalar properties plus a
one-line `summary`, so a client can click a node and read it directly.

Must run AFTER enrich_knowledge_graph(), because it aggregates the verdicts.
"""
from __future__ import annotations

from typing import Dict, List, Set

from .graph_model import Graph

ROUTINE_LABELS = {"Procedure", "Function"}
DECISION_KEY = {
    "CONVERT_TO_PYSPARK": "convert",
    "REWRITE_FOR_PYSPARK": "rewrite",
    "KEEP_IN_ORACLE": "keep",
    "ORCHESTRATION": "orchestration",
}


def _index(g: Graph):
    calls: Dict[str, List[str]] = {}
    stmts_of: Dict[str, Set[str]] = {}
    reads_of: Dict[str, Set[str]] = {}
    writes_of: Dict[str, Set[str]] = {}
    seqs_of: Dict[str, Set[str]] = {}
    verdict_of: Dict[str, str] = {}

    blocks_of: Dict[str, List[str]] = {}
    contains: Dict[str, List[str]] = {}
    executes: Dict[str, List[str]] = {}
    st_reads: Dict[str, List[str]] = {}
    st_writes: Dict[str, List[str]] = {}
    st_seq: Dict[str, List[str]] = {}

    for e in g.edges:
        if e.rel == "CALLS":
            calls.setdefault(e.src, []).append(e.dst)
        elif e.rel == "HAS_BLOCK":
            blocks_of.setdefault(e.src, []).append(e.dst)
        elif e.rel == "CONTAINS":
            contains.setdefault(e.src, []).append(e.dst)
        elif e.rel == "EXECUTES":
            executes.setdefault(e.src, []).append(e.dst)
        elif e.rel == "READS":
            st_reads.setdefault(e.src, []).append(e.dst)
        elif e.rel == "WRITES":
            st_writes.setdefault(e.src, []).append(e.dst)
        elif e.rel == "USES_SEQUENCE":
            st_seq.setdefault(e.src, []).append(e.dst)
        elif e.rel == "ASSESSED_AS":
            a = g.nodes.get(e.dst)
            if a:
                verdict_of[e.src] = a.props.get("decision", "")

    # direct (non-transitive) I/O per routine: walk its own blocks
    for rid, n in g.nodes.items():
        if n.label not in ROUTINE_LABELS:
            continue
        frontier = list(blocks_of.get(rid, []))
        seen: Set[str] = set()
        sts: Set[str] = set()
        while frontier:
            b = frontier.pop()
            if b in seen:
                continue
            seen.add(b)
            sts.update(executes.get(b, []))
            for child in contains.get(b, []):
                cn = g.nodes.get(child)
                if cn and cn.label in ("Block", "Loop", "Branch"):
                    frontier.append(child)
        stmts_of[rid] = sts
        r, w, s = set(), set(), set()
        for st in sts:
            r.update(st_reads.get(st, []))
            w.update(st_writes.get(st, []))
            s.update(st_seq.get(st, []))
        reads_of[rid] = r
        writes_of[rid] = w
        seqs_of[rid] = s

    return calls, stmts_of, reads_of, writes_of, seqs_of, verdict_of


def add_rollups(g: Graph) -> None:
    """Annotate every routine with an aggregate summary of its call subtree."""
    calls, stmts_of, reads_of, writes_of, seqs_of, verdict_of = _index(g)
    routines = [n.id for n in g.nodes.values() if n.label in ROUTINE_LABELS]
    rset = set(routines)
    name = lambda i: (g.nodes[i].props.get("qualified")
                      or g.nodes[i].props.get("name") or i)

    for rid in routines:
        # --- transitive closure of the call subtree (excluding self) ---
        subtree: Set[str] = set()
        depth_of: Dict[str, int] = {}
        stack = [(rid, 0)]
        guard = 0
        while stack and guard < 200000:
            guard += 1
            cur, d = stack.pop()
            for nxt in calls.get(cur, []):
                if nxt == rid:
                    continue
                if nxt in subtree and depth_of.get(nxt, 0) >= d + 1:
                    continue
                subtree.add(nxt)
                depth_of[nxt] = max(depth_of.get(nxt, 0), d + 1)
                if nxt in rset:
                    stack.append((nxt, d + 1))

        sub_routines = {x for x in subtree if x in rset}
        sub_procs = {x for x in sub_routines if g.nodes[x].label == "Procedure"}
        sub_funcs = {x for x in sub_routines if g.nodes[x].label == "Function"}
        externals = {x for x in subtree if g.nodes[x].label == "External"}

        # --- aggregate data objects over self + subtree ---
        scope = {rid} | sub_routines
        reads: Set[str] = set()
        writes: Set[str] = set()
        seqs: Set[str] = set()
        for x in scope:
            reads |= reads_of.get(x, set())
            writes |= writes_of.get(x, set())
            seqs |= seqs_of.get(x, set())
        tables = reads | writes

        # --- verdict breakdown across the subtree (the client-facing bit) ---
        counts = {"convert": 0, "rewrite": 0, "keep": 0, "orchestration": 0}
        for x in sub_routines:
            k = DECISION_KEY.get(verdict_of.get(x, ""))
            if k:
                counts[k] += 1

        p = g.nodes[rid].props
        p["subtree_routines"] = len(sub_routines)
        p["subtree_procedures"] = len(sub_procs)
        p["subtree_functions"] = len(sub_funcs)
        p["subtree_external_calls"] = len(externals)
        p["subtree_depth"] = max(depth_of.values()) if depth_of else 0
        p["subtree_tables"] = len(tables)
        p["subtree_tables_read"] = len(reads)
        p["subtree_tables_written"] = len(writes)
        p["subtree_sequences"] = len(seqs)
        p["subtree_keep_in_oracle"] = counts["keep"]
        p["subtree_convert_to_pyspark"] = counts["convert"]
        p["subtree_rewrite_for_pyspark"] = counts["rewrite"]
        p["subtree_orchestration"] = counts["orchestration"]
        p["subtree_table_names"] = sorted(g.nodes[t].props.get("name", "")
                                          for t in tables)[:50]
        p["subtree_routine_names"] = sorted(name(x) for x in sub_routines)[:50]

        if sub_routines:
            verdict_bits = ", ".join(
                f"{v} {k}" for k, v in
                (("keep in Oracle", counts["keep"]),
                 ("convert", counts["convert"]),
                 ("rewrite", counts["rewrite"]),
                 ("orchestration", counts["orchestration"])) if v
            )
            p["summary"] = (
                f"{len(sub_routines)} routine(s) deep {p['subtree_depth']}, "
                f"{len(tables)} table(s) - {verdict_bits or 'no verdicts'}"
            )
        else:
            p["summary"] = f"leaf - {len(tables)} table(s), no calls"


def rollup_report(g: Graph) -> List[dict]:
    """Flat report rows: one per routine, its own verdict + subtree breakdown."""
    verdict_of = {}
    for e in g.edges:
        if e.rel == "ASSESSED_AS":
            a = g.nodes.get(e.dst)
            if a:
                verdict_of[e.src] = a.props.get("decision", "")
    rows = []
    for n in g.nodes.values():
        if n.label not in ROUTINE_LABELS:
            continue
        p = n.props
        rows.append({
            "routine": p.get("qualified") or p.get("name"),
            "type": n.label,
            "entry_point": p.get("entry_point", False),
            "own_verdict": verdict_of.get(n.id, ""),
            "calls_direct": p.get("calls_out", 0),
            "subtree_routines": p.get("subtree_routines", 0),
            "subtree_depth": p.get("subtree_depth", 0),
            "subtree_tables": p.get("subtree_tables", 0),
            "keep_in_oracle": p.get("subtree_keep_in_oracle", 0),
            "convert_to_pyspark": p.get("subtree_convert_to_pyspark", 0),
            "rewrite_for_pyspark": p.get("subtree_rewrite_for_pyspark", 0),
            "orchestration": p.get("subtree_orchestration", 0),
            "summary": p.get("summary", ""),
        })
    rows.sort(key=lambda r: (-r["subtree_routines"], r["routine"]))
    return rows
