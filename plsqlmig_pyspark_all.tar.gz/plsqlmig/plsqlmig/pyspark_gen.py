"""
PySpark generator.

Default mode: for units the knowledge layer marks CONVERT_TO_PYSPARK or
REWRITE_FOR_PYSPARK, emit a PySpark skeleton. Each SQL statement is transpiled
to Spark SQL (by sqlglot in the analyzer) and wrapped in spark.sql(...).

All-routines mode (include_all=True / CLI --pyspark-all): emit a function for
EVERY procedure and function, whatever its verdict:
  * KEEP_IN_ORACLE  -> same SQL-based body, headed by a clear warning that the
                       verdict says keep in Oracle, plus the blocking constructs
  * ORCHESTRATION   -> a driver body that calls the routines it invokes, in
                       source order (internal calls become Python calls,
                       calls to routines outside the corpus become comments)
Every function also lists the Oracle constructs it uses and their Spark
equivalent from the knowledge base, so the developer sees what must change.

This produces a *starting point* a developer finishes -- not guaranteed runnable
output, especially where the verdict is REWRITE or KEEP_IN_ORACLE.
"""
from __future__ import annotations

from typing import Dict, List

from .graph_model import Graph
from .scorer import UnitScore

GENERATED_BY_DEFAULT = ("CONVERT_TO_PYSPARK", "REWRITE_FOR_PYSPARK")


def _kb():
    # imported lazily to avoid a circular import (knowledge imports scorer)
    from .knowledge import ORACLE_TO_SPARK
    return ORACLE_TO_SPARK


def generate_pyspark(g: Graph, scores: List[UnitScore], include_all: bool = False) -> str:
    by_name = {(s.owner, s.name): s for s in scores}
    # Authoritative decision comes from the knowledge-layer MigrationAssessment,
    # not the raw scorer (the two can differ: e.g. ROW_BY_ROW -> REWRITE).
    assessment: Dict[str, dict] = {e.src: g.nodes[e.dst].props
                                   for e in g.edges if e.rel == "ASSESSED_AS"}
    kb = _kb()
    out: List[str] = [
        "from pyspark.sql import SparkSession",
        "",
        "spark = SparkSession.builder.appName('plsql_migration').enableHiveSupport().getOrCreate()",
        "",
    ]
    if include_all:
        out += ["# Generated in ALL-ROUTINES mode: every procedure/function has a function below,",
                "# whatever its migration verdict. Read the header of each function before use.", ""]

    counts: Dict[str, int] = {}
    for node in g.nodes.values():
        if node.label not in ("Procedure", "Function"):
            continue
        owner = node.props.get("owner", "")
        name = node.props.get("name", "")
        a = assessment.get(node.id, {})
        decision = a.get("decision", "KEEP_IN_ORACLE")
        if not include_all and decision not in GENERATED_BY_DEFAULT:
            continue
        counts[decision] = counts.get(decision, 0) + 1
        s = by_name.get((owner, name))

        out.append(f"def {name.lower()}(spark=spark):")
        out.append(f"    # source: {owner + '.' if owner else ''}{name}  | decision: {decision}"
                   f"  | confidence: {a.get('confidence', '-')}")

        # --- verdict-specific header -------------------------------------
        if decision == "REWRITE_FOR_PYSPARK":
            out.append("    # NOTE: row-by-row / procedural logic — vectorize before use:")
            if s:
                for r in s.rationale:
                    if r.startswith("-Oracle"):
                        out.append(f"    #   {r}")
        elif decision == "KEEP_IN_ORACLE":
            out.append("    # WARNING: verdict is KEEP_IN_ORACLE — generated for completeness/reference only.")
            out.append(f"    #   logic pattern: {a.get('logic_pattern', '-')}")
            if a.get("blocking"):
                out.append(f"    #   blocking constructs (no Spark equivalent): {a['blocking']}")
            out.append("    #   Oracle transaction / row-level semantics are NOT preserved; review before running.")
        elif decision == "ORCHESTRATION":
            out.append("    # ORCHESTRATION: this routine sequences other routines; in Spark it is the driver.")

        # --- Oracle constructs used, with the knowledge-base mapping ---------
        feats = sorted({g.nodes[e.dst].props.get("name", "")
                        for e in g.edges if e.src == node.id and e.rel == "HAS_FEATURE"})
        mapped = [(f, kb[f]) for f in feats if f in kb and kb[f][1] != "DIRECT"]
        if mapped:
            out.append("    # Oracle constructs to handle:")
            for f, (spark_eq, conv, note) in mapped:
                out.append(f"    #   {f} [{conv}] -> {spark_eq}  ({note})")

        # --- orchestration: calls in source order --------------------------
        emitted = False
        if decision == "ORCHESTRATION":
            calls = sorted((e for e in g.edges if e.src == node.id and e.rel == "CALLS"),
                           key=lambda e: e.props.get("seq", 0))
            for e in calls:
                tgt = g.nodes.get(e.dst)
                if tgt is None:
                    continue
                tname = tgt.props.get("name", "")
                if tgt.label in ("Procedure", "Function"):
                    tdec = assessment.get(e.dst, {}).get("decision", "KEEP_IN_ORACLE")
                    if include_all or tdec in GENERATED_BY_DEFAULT:
                        out.append(f"    {tname.lower()}(spark)")
                    else:
                        out.append(f"    # call {tname} -> stays in Oracle ({tdec}); run via the pipeline driver")
                else:
                    out.append(f"    # call {tname} -> external / not in the parsed corpus")
                emitted = True

        # --- SQL statements --------------------------------------------------
        block_ids = {e.dst for e in g.edges if e.src == node.id and e.rel == "HAS_BLOCK"}
        stmt_edges = [e for e in g.edges if e.src in block_ids and e.rel == "EXECUTES"]
        for e in stmt_edges:
            sp = g.nodes[e.dst].props
            spark_sql = sp.get("spark_sql", "")
            if not spark_sql:
                continue
            emitted = True
            writes = [g.nodes[w.dst].props["name"]
                      for w in g.edges if w.src == e.dst and w.rel == "WRITES"]
            sql_one_line = " ".join(spark_sql.split())
            low = sql_one_line.lower()
            if ".nextval" in low:
                out.append("    # NOTE: sequence NEXTVAL has no Spark equivalent — replace with row_number()/uuid()")
            if "@" in sql_one_line:
                out.append("    # NOTE: database link (@dblink) — needs a JDBC read/write instead")
            if writes:
                out.append(f"    # writes: {', '.join(writes)}")
            # repr() so a SQL string that itself ends in a quote character can't
            # break the generated Python string literal. spark.sql() on DML already
            # performs the write — no extra saveAsTable (avoids a double write).
            out.append(f"    spark.sql({repr(sql_one_line)})")
        if not emitted:
            out.append("    pass  # no transpilable SQL extracted")
        out.append("")

    out.append(f"# generated functions by verdict: {counts}")
    return "\n".join(out)
